var mqtt = require('./MQTT')
var client = mqtt.connect('mqtt://localhost:1883')
//var client = mqtt.connect({ port: 1883, host: '192.168.100.6', keepalive: 10000});


client.publish('presence', 'Hello mqtt')

client.on('message', function (topic, message) {
  console.log(message.toString())
})

client.end()