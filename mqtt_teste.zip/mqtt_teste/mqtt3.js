var mqtt = require('./MQTT')
//var client = mqtt.connect()

//var client = mqtt.connect('mqtt://localhost:1883')
// var client = mqtt.connect('mqtt://test.mosquitto.org')
// var client = mqtt.connect({host: 'localhost', port: 1883  });
var client = mqtt.connect({ port: 1883, host: 'localhost'});


var stdin = process.openStdin();

stdin.addListener("data", function(d) {
    // note:  d is an object, and when converted to a string it will
    // end with a linefeed.  so we (rather crudely) account for that  
    // with toString() and then trim() 

    var data = d.toString().trim();

    if(data == "pub"){
    	client.publish('presence', 'testando');
    }

    console.log("you entered: [" + data + "]");
  });
