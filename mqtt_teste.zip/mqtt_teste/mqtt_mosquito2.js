var mqtt = require('mqtt')
var client = mqtt.connect('mqtt://test.mosquitto.org')
//var client  = mqtt.connect({ port: 1883, host: 'localhost', keepalive: 10000})

client.on('connect', function () {
		client.subscribe('presence')
      //client.publish('presence', 'Funcionou')

})

client.on('message', function (topic, message) {
  // message is Buffer
  console.log(message.toString())
  client.end()
})

