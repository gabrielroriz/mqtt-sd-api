var mqtt = require('./MQTT')
//var client = mqtt.connect()

//var client = mqtt.connect('mqtt://localhost:1883')
// var client = mqtt.connect('mqtt://test.mosquitto.org')
// var client = mqtt.connect({host: 'localhost', port: 1883  });
var client = mqtt.connect({ port: 1883, host: 'localhost', keepalive: 100});

console.log("starting")
client.subscribe({topic: 'presence', qos: 0 }, function (err, granted) {
	console.log("Oi")
	console.log(granted, err);
 });

client.on('message', function (topic, message) {
  console.log(message.toString())
})

// client.end()
  //client.end()


